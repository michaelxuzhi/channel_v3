# 解决sublime 的 package control 问题here are no packages available for installation
参考https://blog.csdn.net/zknxx/article/details/52685094
关于 channel_v3.json 文件 ,下载的压缩包里没有, 需要下载https://packagecontrol.io/channel_v3.json 页面
但是这个页面我发现一开始没有打开, 可以在这里下载, https://download.csdn.net/download/su_cicada/10568987
积分至少 1真坑,不想出积分的可以下载上面的
